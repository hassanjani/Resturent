import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:onesignal_flutter/onesignal_flutter.dart';

class NotifyOther extends StatefulWidget {
  @override
  _NotifyOtherState createState() => _NotifyOtherState();
}

class _NotifyOtherState extends State<NotifyOther> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }

  Future<void> initalPlatform() async {
    await OneSignal.shared.setAppId("");
    await OneSignal.shared
        .getDeviceState()
        .then((value) => {print(value.userId)});
  }

  @override
  void initState() {
    super.initState();
    initalPlatform();
  }
}
