import 'package:flutter/material.dart';

class Category{
  int id;
  String tittle;
  String description;
  String imagePath;
  Category(this.id,this.tittle, this.description, this.imagePath);
}

